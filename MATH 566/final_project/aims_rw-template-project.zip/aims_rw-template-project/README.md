This is the AIMS South Africa Structured Masters Research Project LaTeX Template and Guidelines.
