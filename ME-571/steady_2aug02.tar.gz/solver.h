#ifndef _SOLVER_
#define _SOLVER_

void Solve_A (double *u);
void Build_A (void);

#endif /* ifndef _SOLVER_ */
