function y = g(q,xi)
% Funtion to be solved using Newton
y = a(q)-xi;
end