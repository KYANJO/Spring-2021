% function whose zero we need to compute 
function gk=g(q,xi) 
gk = a(q)-xi; 
