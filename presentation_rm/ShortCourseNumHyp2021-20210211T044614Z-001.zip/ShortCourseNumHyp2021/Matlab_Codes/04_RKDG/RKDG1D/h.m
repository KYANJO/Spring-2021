function q=h(x)
% IC
q = 1 + 0.1*exp(-0.5*(x+0.25)^2/0.1^2); 
end